var allentries=[1];
